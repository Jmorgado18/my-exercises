package io.CodeForAll.fanstatics;

public class Genie {
    protected int nrOfWishes;


    public Genie(int nrOfWishes){
        this.nrOfWishes=nrOfWishes;
    }
    public void doWish() {
        System.out.println("A wish is being granted." );
    }
}

