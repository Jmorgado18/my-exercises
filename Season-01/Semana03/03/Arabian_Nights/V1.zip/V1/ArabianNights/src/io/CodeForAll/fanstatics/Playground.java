package io.CodeForAll.fanstatics;

public class Playground {
    public static void main(String[] args) {
        Lamp lamp1 = new Lamp(3);
        lamp1.rub();
        lamp1.rub();
        lamp1.rub();
        lamp1.rub();
    }
}