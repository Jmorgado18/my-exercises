package io.codeforall.bootcamp.cars;

public class Fiat extends Car{

}
