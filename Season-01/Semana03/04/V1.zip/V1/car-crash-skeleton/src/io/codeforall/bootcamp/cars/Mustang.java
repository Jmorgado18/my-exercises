package io.codeforall.bootcamp.cars;

public class Mustang extends Car{
}
