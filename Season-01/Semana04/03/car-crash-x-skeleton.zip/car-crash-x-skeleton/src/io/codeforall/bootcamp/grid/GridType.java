package io.codeforall.bootcamp.grid;

/**
 * The available types of grids
 */
public enum GridType {

    LANTERNA,
    SIMPLE_GFX

}
