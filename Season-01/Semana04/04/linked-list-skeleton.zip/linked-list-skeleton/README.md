Simple linked list implementation
