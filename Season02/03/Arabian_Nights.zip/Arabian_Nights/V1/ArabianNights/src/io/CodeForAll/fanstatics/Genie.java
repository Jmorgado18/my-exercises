package io.CodeForAll.fanstatics;

public class Genie {
    private int nrOfWishes;


    public Genie(){
        this.nrOfWishes=nrOfWishes;
    }

}

